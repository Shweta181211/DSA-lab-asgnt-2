#include <iostream>
#include <string>
using namespace std;

bool isVowel(char c) {
    c = (c >= 'A' && c <= 'Z') ? (c + 32) : c; 
    return (c=='a'||c=='e'||c=='i'||c=='o'||c=='u');
}

int main() {
    string s, out = "";
    cout << "String: ";
    getline(cin >> ws, s);

    for (int i = 0; i < (int)s.size(); i++)
        if (!isVowel(s[i])) out += s[i];

    cout << "After removing vowels: " << out << "\n";
    return 0;
}
