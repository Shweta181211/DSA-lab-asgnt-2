#include<iostream>
using namespace std;

int main()
{
    int n,m;
    cin>>n;
    int a[20][3],b[20][3],c[40][3];

    for(int i=0;i<=n;i++) cin>>a[i][0]>>a[i][1]>>a[i][2];
    cin>>m;
    for(int i=0;i<=m;i++) cin>>b[i][0]>>b[i][1]>>b[i][2];

    int i=1,j=1,k=1;
    c[0][0]=a[0][0]; c[0][1]=a[0][1];

    while(i<=n && j<=m)
    {
        if(a[i][0]==b[j][0] && a[i][1]==b[j][1])
        {
            c[k][0]=a[i][0]; 
            c[k][1]=a[i][1];
            c[k][2]=a[i][2]+b[j][2];
            i++; j++; k++;
        }
        else if(a[i][0]<b[j][0] || 
        (a[i][0]==b[j][0] && a[i][1]<b[j][1]))
        {
            c[k][0]=a[i][0]; c[k][1]=a[i][1]; c[k][2]=a[i][2];
            i++; k++;
        }
        else
        {
            c[k][0]=b[j][0]; c[k][1]=b[j][1]; c[k][2]=b[j][2];
            j++; k++;
        }
    }

    while(i<=n) c[k][0]=a[i][0],c[k][1]=a[i][1],c[k][2]=a[i][2],i++,k++;
    while(j<=m) c[k][0]=b[j][0],c[k][1]=b[j][1],c[k][2]=b[j][2],j++,k++;

    c[0][2]=k-1;

    for(int p=0;p<k;p++)
        cout<<c[p][0]<<" "<<c[p][1]<<" "<<c[p][2]<<endl;

    return 0;
}
