#include <iostream>
#include <string>
using namespace std;

int main() {
    int n;
    cout << "How many strings? ";
    cin >> n;
    string a[100];
    for (int i = 0; i < n; i++) {
        cout << "s" << i+1 << ": ";
        getline(cin >> ws, a[i]);
    }

    for (int i = 0; i < n-1; i++) {
        for (int j = 0; j < n-1-i; j++) {
            if (a[j] > a[j+1]) {
                string t = a[j];
                a[j] = a[j+1];
                a[j+1] = t;
            }
        }
    }

    cout << "Sorted:\n";
    for (int i = 0; i < n; i++) cout << a[i] << "\n";
    return 0;
}
