#include<iostream>
using namespace std;

int main()
{
    int r,c,n;
    cout<<"Enter rows cols and non-zero count: ";
    cin>>r>>c>>n;

    int a[20][3];
    a[0][0]=r; a[0][1]=c; a[0][2]=n;

    cout<<"Enter row col value:\n";
    for(int i=1;i<=n;i++)
        cin>>a[i][0]>>a[i][1]>>a[i][2];

    int t[20][3];
    t[0][0]=c; t[0][1]=r; t[0][2]=n;

    int k=1;
    for(int i=0;i<c;i++)
    {
        for(int j=1;j<=n;j++)
        {
            if(a[j][1]==i)
            {
                t[k][0]=a[j][1];
                t[k][1]=a[j][0];
                t[k][2]=a[j][2];
                k++;
            }
        }
    }

    cout<<"\nTranspose (Triplet):\n";
    for(int i=0;i<=n;i++)
        cout<<t[i][0]<<" "<<t[i][1]<<" "<<t[i][2]<<endl;

    return 0;
}
