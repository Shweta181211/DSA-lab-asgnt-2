#include <iostream>
using namespace std;

int main() {
    int n; cout << "n: "; cin >> n;
    int sz = n*(n+1)/2;
    int a[10000]; for (int i = 1; i <= sz; i++) a[i] = 0;

    auto setVal = [&](int i, int j, int val){
        if (j <= i) {
            int idx = i*(i-1)/2 + j;
            a[idx] = val;
        }
    };

    int m; cout << "Non-zeros count: "; cin >> m;
    while (m--) {
        int i,j,v; cin >> i >> j >> v;
        setVal(i,j,v);
    }

    cout << "Full matrix:\n";
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            int x = 0;
            if (j <= i) {
                int idx = i*(i-1)/2 + j;
                x = a[idx];
            }
            cout << x << " ";
        }
        cout << "\n";
    }
    return 0;
}
