#include <iostream>
using namespace std;

int findMissingBinary(int a[], int nMinus1) {
    int l = 0, r = nMinus1 - 1, ans = nMinus1 + 1; 
    while (l <= r) {
        int mid = (l + r) / 2;
        int expected = mid + 1;          
        if (a[mid] == expected) {
            l = mid + 1;                  
        } else {
            ans = expected;               
            r = mid - 1;              
        }
    }
    return ans;
}

int main() {
    int n;
    cout << "Enter n (full range 1..n): ";
    cin >> n;
    int a[100];
    cout << "Enter sorted array of size " << (n - 1) << " (missing one):\n";
    for (int i = 0; i < n - 1; i++) cin >> a[i];

    cout << "Missing (binary) = " << findMissingBinary(a, n - 1) << "\n";
    return 0;
}
