#include <iostream>
using namespace std;

int main() {
    int n; cout << "n: "; 
    cin >> n;
    int d[100]; 
    for (int i = 1; i <= n; i++) d[i] = 0;

    int m; cout << "How many diagonal elements to set? "; cin >> m;
    for (int k = 0; k < m; k++) {
        int i, val; cout << "i val: "; cin >> i >> val;
        if (i>=1 && i<=n) d[i] = val;
    }

    cout << "Full matrix:\n";
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            if (i == j) cout << d[i] << " ";
            else cout << 0 << " ";
        }
        cout << "\n";
    }
    return 0;
}
