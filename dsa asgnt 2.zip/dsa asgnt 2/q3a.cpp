#include <iostream>
using namespace std;

int findMissingLinear(int a[], int n) {
    for (int i = 0; i < n; i++) {
        int expected = i + 1;
        if (a[i] != expected) return expected;
    }
    return n + 1; 
}

int main() {
    int n1;
    cout << "Enter n (full range): ";
    cin >> n1;
    int a1[100];
    cout << "Enter sorted array of size " << (n1 - 1) << " (missing one):\n";
    for (int i = 0; i < n1 - 1; i++) cin >> a1[i];

    cout << "Missing (linear) = " << findMissingLinear(a1, n1 - 1) << "\n";
    return 0;
}
