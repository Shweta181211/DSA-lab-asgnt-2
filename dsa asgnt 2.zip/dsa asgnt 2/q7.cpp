#include<iostream>
using namespace std;

int main()
{
    int n;
    cin>>n;
    int a[100],i,j,count=0;

    for(i=0;i<n;i++)
        cin>>a[i];

    for(i=0;i<n;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(a[i] > a[j])
                count++;
        }
    }

    cout<<"Inversions = "<<count;
    return 0;
}
