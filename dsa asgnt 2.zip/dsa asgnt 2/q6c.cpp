#include<iostream>
using namespace std;

int main()
{
    int r1,c1,n1;
    cout<<"Enter rows cols and non-zero count of Matrix A: ";
    cin>>r1>>c1>>n1;

    int A[20][3];
    A[0][0]=r1; A[0][1]=c1; A[0][2]=n1;

    cout<<"Enter triplet (row col value) for A:\n";
    for(int i=1;i<=n1;i++)
        cin>>A[i][0]>>A[i][1]>>A[i][2];

    int r2,c2,n2;
    cout<<"Enter rows cols and non-zero count of Matrix B: ";
    cin>>r2>>c2>>n2;

    int B[20][3];
    B[0][0]=r2; B[0][1]=c2; B[0][2]=n2;

    cout<<"Enter triplet (row col value) for B:\n";
    for(int i=1;i<=n2;i++)
        cin>>B[i][0]>>B[i][1]>>B[i][2];

    if(c1 != r2)
    {
        cout<<"Matrix multiplication not possible";
        return 0;
    }

    int M1[20][20]={0}, M2[20][20]={0};

    for(int i=1;i<=n1;i++)
        M1[A[i][0]][A[i][1]] = A[i][2];

    for(int i=1;i<=n2;i++)
        M2[B[i][0]][B[i][1]] = B[i][2];

    int R[20][20]={0};
    for(int i=0;i<r1;i++)
    {
        for(int j=0;j<c2;j++)
        {
            for(int k=0;k<c1;k++)
                R[i][j] += M1[i][k] * M2[k][j];
        }
    }

    int T[50][3];
    int k=1;
    T[0][0]=r1;
    T[0][1]=c2;

    for(int i=0;i<r1;i++)
    {
        for(int j=0;j<c2;j++)
        {
            if(R[i][j] != 0)
            {
                T[k][0]=i;
                T[k][1]=j;
                T[k][2]=R[i][j];
                k++;
            }
        }
    }
    T[0][2] = k-1;

    cout<<"\nResult Triplet Matrix:\n";
    for(int i=0;i<k;i++)
        cout<<T[i][0]<<" "<<T[i][1]<<" "<<T[i][2]<<endl;

    return 0;
}
