#include <iostream>
using namespace std;

int main() {
    int n; cout << "n: "; cin >> n;
    int sz = 3*n - 2;
    int t[300]; for (int i = 1; i <= sz; i++) t[i] = 0;

    auto setVal = [&](int i, int j, int val){
        if (j == i-1) t[i-1] = val;
        else if (j == i) t[(n-1) + i] = val;
        else if (j == i+1) t[(2*n-1) + i] = val;
    };

    int m; cout << "How many non-zeros to set? "; cin >> m;
    while (m--) {
        int i,j,v; cin >> i >> j >> v;
        setVal(i,j,v);
    }

    cout << "Full matrix:\n";
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            int x = 0;
            if (j == i-1) x = t[i-1];
            else if (j == i) x = t[(n-1)+i];
            else if (j == i+1) x = t[(2*n-1)+i];
            cout << x << " ";
        }
        cout << "\n";
    }
    return 0;
}
