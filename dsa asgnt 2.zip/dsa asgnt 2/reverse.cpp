#include <iostream>
#include <string>
using namespace std;

int main() {
    string s;
    cout << "String";
    getline(cin >> ws, s);

    int i = 0, j = (int)s.size() - 1;
    while (i < j) {
        char t = s[i];
        s[i] = s[j];
        s[j] = t;
        i++; j--;
    }
    cout << "Reversed" << s << "\n";
    return 0;
}
